from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/', methods = ['GET', 'POST'])
def submit():
    if request.method == 'POST':
        if request.form['submit'] == "Submit":
            return redirect(url_for('/results'))
@app.route('/results', methods = ['GET', 'POST'])
def results():    
    return render_template('results.html', name = request.form['name'], location = request.form['location'], language = request.form['language'], comment = request.form['comment'])
app.debug = True
app.run()