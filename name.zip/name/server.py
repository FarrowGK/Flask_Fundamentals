from flask import Flask, render_template,request, redirect, session
app = Flask(__name__)
# @app.route('/')
# def index():
#     return render_template('index.html')
@app.route('/', methods = ['GET', 'POST'])
def redirect():
    return render_template('index.html')
    if request.method == 'POST':
        return redirect(url_for('/process'))
@app.route('/process', methods = ['GET', 'POST'])
def process():
    return render_template('process.html', name = request.form['name'], email = request.form['email'])
    return redirect(url_for('/'))
app.debug = True
app.run()
